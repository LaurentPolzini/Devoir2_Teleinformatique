# Devoir2_Teleinformatique
Voici le repo du 2ème devoir de Téléinformatique à l'UDeM.

Les auteurs sont Paul BOULESTEIX et Laurent POLZIN. Voici nos matricules respectifs : 20198839 et 20345581.

protocole_py.py recv output_timeout.txt avec optionellement des parametres dans un terminal pour recepteur, terminal à l'emplacement du ficher protocole
python protocole_py.py send test.txt 0.05 0.10 200 0.1 dans un autre pour envoyeur

La structure des fichiers n'est pas respectée et nous nous en excusons (message de test est test.txt, dans code)
