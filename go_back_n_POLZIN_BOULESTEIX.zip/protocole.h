#ifndef __PROTOCOLE_H__
#define __PROTOCOLE_H__

#include <unistd.h>
#include <stdlib.h>

#define DELIMITER 0x7E // 01111110
static const size_t DATA_MAX_LEN = 100; // 100 octets est la taille maximale de la trame hors CRC et en tete (donc juste données)

/*
    DELIMITERS will be put when sending. The frame will be transformed into
    a sequence of bytes.
*/
typedef struct frame_s {
    uint8_t commande;     /* type de paquet, cf. ci-dessous */
    uint8_t num_seq;      /* numéro de séquence */
    uint16_t somme_ctrl;   /* somme de contrôle */
    uint8_t info[DATA_MAX_LEN];  /* données utiles du paquet */
    size_t lg_info;      /* longueur du champ info */
} frame_t;

#define DATA          1  /* données de l'application */
#define ACK           2  /* accusé de réception des données */
#define CON_REQ       3  /* demande d'établissement de connexion */
#define CON_ACCEPT    4  /* acceptation de connexion */
#define CON_REFUSE    5  /* refus d'établissement de connexion */
#define CON_CLOSE     6  /* notification de déconnexion */
#define CON_CLOSE_ACK 7  /* accusé de réception de la déconnexion */
#define OTHER         8  /* extensions */

// protocole
void protocole_go_back_n(char *datas_file_name);

int verify_CRC(frame_t *frame, uint16_t attendu);

uint16_t calculate_CRC(const uint8_t *data, size_t len);

frame_t createFrame(uint8_t *datas, uint8_t seqnuM, uint8_t comm, size_t dataLeng);

//---- GETTERS ----
uint8_t getCommande(frame_t frame);

uint8_t getNum_seq(frame_t frame);

uint16_t getSomme_ctrl(frame_t frame);

uint8_t *getInfo(frame_t *frame);

size_t getLengthInfo(frame_t frame);

/*
    Returns an array of [commande, num_seq, size_data, datas]
*/
uint8_t *getCoreFrame(frame_t *frame);

size_t getLengDatas(uint8_t *datas);

//---- COMPARATORS ----
int array_frames_equals(frame_t *sent, frame_t *received, int nbFrames);

int compareFrames(frame_t *sent, frame_t *received);

int compareCommande(frame_t sent, frame_t received);

int compareNumSeq(frame_t sent, frame_t received);

int compareCtrlSum(frame_t sent, frame_t received);

int compareLg(frame_t sent, frame_t received);

int compareInfos(frame_t *sent, frame_t *received);

//---- SETTERS ----
void setCommande(frame_t *frame, uint8_t comm);

void setNum_seq(frame_t *frame, uint8_t numSeq);

void setSomme_ctrl(frame_t *frame, uint16_t ctrl_sum);

void setInfo(frame_t *frame, uint8_t *datas, size_t lengthDatas);


void setLengInfo(frame_t *frame, size_t lg);

void setFrameLost(frame_t *frame);

frame_t *framesFromFile(char *file_name, int *nbOfFramesCreated);

void afficheFrame(frame_t *frame);

uint8_t *frame_to_bytes_stuffed(frame_t *frame, size_t *lenConvertedFrame);

frame_t bytesToFrame_destuffed(uint8_t *bytes, size_t lenBytes, uint16_t *realCRC);



//---- deprecated
// old protocols, non fonctionnels.
void go_back_n_recepteur(void);
void go_back_n_emetteur(char *datas_file_name);

//--- Python Calls
uint8_t *frame_t_to_char_seq(frame_t *frame, size_t *lenFrame);

// Parses the received flux to a frame structure
frame_t parseFlux(uint8_t *flux, size_t len);

// calculates a CRC from a frame
uint16_t calculate_CRC_python(frame_t *frame);
//--- End Python

#endif
